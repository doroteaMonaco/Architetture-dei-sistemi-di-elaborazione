The solution is logically correct but hasn't really been tested on the board, so feel free to use it as a guide, not as a surely working solution.

I also provided the "count_bits_to_1.s" assembly file.
Andrea Spitale
